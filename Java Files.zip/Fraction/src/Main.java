import java.util.*;
public class Main {
    public static void main(String[] args){
        Fraction f1 = new Fraction(3,8);
        Fraction f2 = new Fraction(1,4);
        Scanner S = new Scanner(System.in);
        int a = S.nextInt();
       if(a ==1) {
           Fraction b = f1.sum(f2);
           System.out.println(b.toString());
       }
       else if(a==2) {
           if(f1.compareTo(f2)>0) {
               Fraction c = f1.sub(f2);
               System.out.println(c.toString());
           }
           else {
               Fraction c = f2.sub(f1);
               System.out.println(c.toString());
           }
       }
       else if(a==3){
           Fraction d = f1.div(f2);
           System.out.println(d.toString());
       }
       else if(a==4) {
           Fraction e = f1.mul(f2);
           System.out.println(e.toString());
       }
    }
}