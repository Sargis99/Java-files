import java.util.*;
public class Ex1 {
    public static void main(String[] args){
        Scanner a = new Scanner(System.in);
        while(true){
            int x = a.nextInt();
            int y = a.nextInt();
            int t;
            while(y!=0){
                    t = x;
                    x = y;
                    y = t% y;

            }
            System.out.println(x);
        }
    }
}
