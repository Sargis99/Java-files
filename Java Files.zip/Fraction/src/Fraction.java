import java.util.*;
public class Fraction {
    private int a,b;
    Fraction(int x, int y) {
        a = x; b = y;
    }
    public String toString(){
        return a + "/" + b;
    }
    public Fraction sum(Fraction x){
        return new Fraction(a*x.b+b*x.a, b*x.b);
    }
    public int compareTo(Fraction x){
        return a*x.b - b*x.a; //result: 0, <0 o >0
    }
    public Fraction sub(Fraction x) {
        return new Fraction(a*x.b-b*x.a,b*x.b);
    }
    public Fraction div(Fraction x) {
        return new Fraction(a*x.b,b*x.a);
    }
    public Fraction mul(Fraction x) {
        return new Fraction(a*x.a,b*x.b);
    }

}
