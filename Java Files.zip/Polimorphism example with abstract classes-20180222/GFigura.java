public abstract class GFigura {

   int x, y; //coordenadas del centro de la figura

   GFigura(int x, int y) {
     this.x = x;
     this.y = y;
   }
   
   public void mover(int dx, int dy) {
      //MUEVE EL ORIGEN DE LA FIGURA
      x = x + dx; 
      y = y + dy;
   }

   abstract public void dibujar(Console x); 
   abstract public void escalar(double factor);
}
