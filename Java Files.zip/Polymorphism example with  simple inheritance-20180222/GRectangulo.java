public class GRectangulo extends GFigura {

   int alto, ancho; 

   GRectangulo(int a, int b, int c, int d) {
      super(a,b); alto = c; ancho = d;
   }

   public void dibujar(Console c) {
      //fillRect(x,y,,ancho,alto) DIBUGA UN RECTANGULO
      //CON ESQUINA SUPERIOR IZQUIERDA EN x,y y de alto y ancho dados
      c.fillRect(x,y,alto,ancho);
   } 

   public void escalar(double factor) {
      //escala el tama�o de la figura por el factor dado 
      ancho = (int)(ancho*factor); 
      alto = (int)(alto*factor); 
    } 

}
