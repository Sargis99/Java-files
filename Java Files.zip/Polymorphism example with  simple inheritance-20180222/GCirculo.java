public class GCirculo extends GFigura {

   int radio; //radio

   GCirculo(int a, int b, int c) {
      super(a,b); radio = c; 
   }

   public void dibujar(Console c) {
      //fillOval(x,y,ancho,alto) DIBUGA UN CIRCULO DENTRO DE UN RECTANGULO
      //CON ESQUINA SUPERIOR IZQUIERDA EN x,y y de alto y ancho dados
      c.fillOval(x,y,radio*2,radio*2);
   } 

   public void escalar(double factor) {
      radio = (int)(radio*factor);
   } //ESPECIFICO PARA CADA FIGURA

}
