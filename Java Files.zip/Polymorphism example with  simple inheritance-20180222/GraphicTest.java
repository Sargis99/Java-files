import java.util.*;

  public class GraphicTest {

       static GFigura[] fs = new GFigura[100];
       static int n = 0; //number of figures created so far
       static Console gr = new Console(); //a pre-defined class to show figures
       //Console is a window for drawing figures in a simple way, not from Java libraries

       //static variables can be accessed from any method in this file

      public static void main(String args[]) {
 		int a,b,d,h,dx,dy;
 		double f;
 		gr.setLocation(100,100); 
                Scanner c = new Scanner(System.in); 

 		while(true) {
 		    System.out.print("1-Circle 2-Rectangle  3-Move 4-Rezise 5-Triangle 0- end:");
 		    int x = c.nextInt();
 		    if (x == 1) {
 		      	System.out.print("x ? "); a = c.nextInt();
 		      	System.out.print("y ? "); b = c.nextInt();
 		      	System.out.print("radius ? "); d = c.nextInt();
 			fs[n++] = new GCirculo(a,b,d); 
	 		redraw();
 		    } else if (x == 2) {
 		      	System.out.print("x ? "); a = c.nextInt();
 		      	System.out.print("y ? "); b = c.nextInt();
 		      	System.out.print("w ? "); d = c.nextInt();
 		      	System.out.print("h ? "); h = c.nextInt();
	 		fs[n++] = new GRectangulo(a,b,d,h);
	 		redraw();
 		    } else if (x == 3) {
 		      	System.out.print("dx ? "); dx = c.nextInt();
 		      	System.out.print("dy ? "); dy = c.nextInt();
	 		move(dx,dy);
	 		redraw();
 		    } else if (x == 4) {
 		      	System.out.print("f ? "); f = c.nextDouble();
	 		scale(f);
	 		redraw();
 		    } else if (x == 0) {
 		      	System.exit(0);
		    } else if (x == 5) {
                        System.out.print("x ? "); a = c.nextInt();
 		      	System.out.print("y ? "); b = c.nextInt();
 		      	System.out.print("leg 1 ? "); d = c.nextInt();
 		      	System.out.print("leg 2 ? "); h = c.nextInt();
                        fs[n++] = new GTriangulo(a,b,d,h);
                        redraw();
 		    } else
    		       	System.out.println("not a valid option");
 		}
 	}

        public static void redraw() {
 	   gr.clear();
 	   for(int i=0; i < n; i++) 
 	      fs[i].dibujar(gr); 
        }

  	public static void move(int dx, int dy) {
 	   for(int i=0; i < n; i++) 
 	      fs[i].mover(dx,dy); 
 	}

  	public static void scale(double f) {
 	   for(int i=0; i < n; i++) 
 	      fs[i].escalar(f); 
 	}
 }