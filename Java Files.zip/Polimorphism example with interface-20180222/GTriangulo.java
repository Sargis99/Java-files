public class GTriangulo implements GFigura {

   int x, y, leg1, leg2; 

   GTriangulo(int a, int b, int c, int d) {
     x = a; y = b; leg1 = c; leg2 = d;
   }

   public void mover(int dx, int dy) {
      x += dx;
      y += dy;
   }

   public void dibujar(Console c) {
      //fillPolygon(x,y) DIBUJA UN POLIGINO
      //CON vertices en (x[i],y[i])
      int xs[] = {x, x, x+leg2}, ys[] = {y, y-leg1, y};
      c.fillPolygon(xs,ys,3); 
   } 

   public void escalar(double factor) {
      //escala el tama�o de la figura por el factor dado 
      leg1 = (int)(leg1*factor); 
      leg2 = (int)(leg2*factor); 
    } 

}
