public class GCirculo implements GFigura {

   int x, y, radio; //radio

   GCirculo(int a, int b, int c) {
      x = a; y = b; radio = c; 
   }

   public void mover(int dx, int dy) {
      x += dx;
      y += dy;
   }

   public void dibujar(Console c) {
      //fillOval(x,y,ancho,alto) DIBUGA UN CIRCULO DENTRO DE UN RECTANGULO
      //CON ESQUINA SUPERIOR IZQUIERDA EN x,y y de alto y ancho dados
      c.fillOval(x,y,radio*2,radio*2);
   } 

   public void escalar(double factor) {
      radio = (int)(radio*factor);
   } //ESPECIFICO PARA CADA FIGURA

}
