public interface GFigura {
   
   public void mover(int dx, int dy);
   public void dibujar(Console x) ;
   public void escalar(double factor); 
}
