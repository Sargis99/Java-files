import java.util.Scanner;

public class Main {
    public static void main(String[] args){
        Scanner sc = new Scanner(System.in);
        int x,y;
        System.out.println("enter dif");
        int dif = sc.nextInt();
        switch (dif) {
            case 1: {
                int i=0;
                int speed = 20;
                User user = new User(0, 0, 90, 200, 20);
                Bomb[] bombs = new Bomb[5];
                Treasure[] treasures = new Treasure[5];
                while(true)
                {
                    x = rint(-60, 60);
                    y = rint(-60, 60);
                    if(distance(x,y,0,0)<=60) {
                        bombs[i] = new Bomb(x, y, rint(5, 15));
                        i++;
                    }
                    if(i==5) {
                        i=0;
                        break;
                    }

                }
                while(true)
                {
                    x = rint(-60, 60);
                    y = rint(-60, 60);
                    if(distance(x,y,0,0)<=60) {
                        treasures[i] = new Treasure(x, y, rint(5, 15));
                        i++;
                    }
                    if(i==5)
                        break;

                }
                playGame(user, bombs, treasures,speed, sc,60);
                break;
            }
            case 2:{
                int i=0;
                int speed = 15;
                User user = new User(0, 0, 90, 100, 15);
                Bomb[] bombs = new Bomb[5];
                Treasure[] treasures = new Treasure[5];
                while(true)
                {
                    x = rint(-80, 80);
                    y = rint(-80, 80);
                    if(distance(x,y,0,0)<=80) {
                        bombs[i] = new Bomb(x, y, rint(10, 25));
                        i++;
                    }
                    if(i==5) {
                        i=0;
                        break;
                    }

                }
                while(true)
                {
                    x = rint(-80, 80);
                    y = rint(-80, 80);
                    if(distance(x,y,0,0)<=80) {
                        treasures[i] = new Treasure(x, y, rint(10, 25));
                        i++;
                    }
                    if(i==5)
                        break;

                }
                playGame(user, bombs, treasures, speed, sc,80);
                break;
            }
            case 3: {
                int i=0;
                int speed= 10;
                User user = new User(0, 0, 90, 50, 20);
                Bomb[] bombs = new Bomb[5];
                Treasure[] treasures = new Treasure[5];
                while(true)
                {
                    x = rint(-1000, 100);
                    y = rint(-100, 100);
                    if(distance(x,y,0,0)<=100) {
                        bombs[i] = new Bomb(x, y, rint(20, 30));
                        i++;
                    }
                    if(i==5) {
                        i=0;
                        break;
                    }

                }
                while(true)
                {
                    x = rint(-100, 100);
                    y = rint(-100, 100);
                    if(distance(x,y,0,0)<=100) {
                        treasures[i] = new Treasure(x, y, rint(20, 30));
                        i++;
                    }
                    if(i==5)
                        break;

                }
                playGame(user, bombs, treasures, speed, sc,100);
                break;
            }
            default: break;
        }
    }
    public static int rint(int x,int y){
        return x + (int)(Math.random()*(y-x+1));
    }
    public static double  distance(double x,double  y, int x1,int y1){
        return Math.sqrt(Math.pow(x1 - x, 2) + Math.pow(y1 - y, 2));
    }
    public static void playGame(User user, Bomb[] bombs, Treasure[] treasures,  int speed, Scanner sc,int radius) {
        while(true) {
            if(user.dead()) {
                break;
            } else {
                System.out.println("move X");
                String xS = sc.next();
                if(xS.equals("exit")) {
                    break;
                }
                double x = Double.parseDouble(xS);
                if (x<= speed) {
                    System.out.println("move Y");
                    String yS = sc.next();
                    if (yS.equals("exit")) {
                        break;
                    }

                    double y = Double.parseDouble(yS);
                    user.rotate(y);
                    user.advance(x);
                    if (distance(user.getX(), user.getY(), 0, 0) >radius ) {
                        System.out.println("You are out of island");
                        break;
                    }

                    for (int i = 0; i < bombs.length; i++) {
                        if (bombs[i].near(user, 2)) {
                            bombs[i].found(user);
                        }




                        if(treasures[i].near(user, 3) ) {
                            treasures[i].disable();
                            treasures[i].found(user);

                        }

                        if (treasures[i].near(user, 3)) {
                            treasures[i].found(user);
                        }
                    }
                    System.out.println("user distance from center is " + user.getDist(0, 0));
                    System.out.println("user X cordinates is " + user.getX() + " Y cordniates is " + user.getY());
                    System.out.println("user life is " + user.getLife());
                    System.out.println("user value is " + user.getValue());
                }

                else{
                    System.out.println("Your maximum speed is "+ speed);
                }
            }
        }
    }
}
