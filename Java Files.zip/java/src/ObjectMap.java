public class ObjectMap {
    protected int x, y;
   protected boolean active;
    ObjectMap(int x, int y) {
        this.x = x;
        this.y = y;
        active = true;
    }

    public boolean near(User x, double minDist) {
        if(x.getDist(this.x, this.y) < minDist) {
            return true;
        }
        return false;
    }

    public void disable() {
        active = false;
    }
}


