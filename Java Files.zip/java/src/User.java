
public class User {
    private int x,y;
    private double alpha;
    private int life;
    private int value;
    private int speed;
    User (int x, int y, int alpha, int life, int speed){
        this.x = x;
        this.y = y;
        this.alpha = alpha;
        this.life = life;
        this.speed = speed;
        value = 0;
    }
    public void advance (double dist){
        x += (double)dist * Math.cos(Math.PI * alpha/180);
        y += (double)dist * Math.sin(Math.PI * alpha/180);
    }
    public void rotate (double alpha){
        this.alpha += alpha;
    }
    public double getAlpha(){
        return alpha;
    }
    public int getValue() {
        return value;
    }
    public int getLife() {
        return life;
    }
    public boolean dead (){
        if(life <= 0) {
            return true;
        }
        return false;
    }
    public void addTreasure(int x){
        value+=x;
    }
    public void substructlif(int x){
        life-=x;
    }
    public double getDist(int x, int y) {
        return Math.sqrt(Math.pow(this.x - x, 2) + Math.pow(this.y - y, 2));
    }
    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }
}
