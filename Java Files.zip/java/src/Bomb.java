public class Bomb extends ObjectMap {
    private int damage;
    Bomb(int x, int y, int d) {
        super(x, y);
        damage = d;
    }

    public void found(User x) {
        super.disable();
        x.substructlif(damage);
        System.out.println("bomb exploded, -life with " + damage);

    }
}
