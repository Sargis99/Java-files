public class Treasure extends ObjectMap {
    private int value;
    Treasure (int x, int y, int v) {
        super(x, y);
        value = v;
    }

    public void found(User x) {
        this.disable();
        x.addTreasure(value);
        System.out.println("treasure founded, +value with" + value);
    }
}
