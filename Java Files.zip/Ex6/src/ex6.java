import java.util.*;
public class ex6 {
    public static void main(String[] args){
        Scanner a = new Scanner(System.in);
        int[][] b = new int[10][3];
        int [] sum = new int[10];
        for (int i = 0; i< 10 ; i++) {
            for (int j = 0; j < 3; j++)
                b[i][j] = 0;
            sum[i]=0;
        }

        while(true) {

            int stn = a.nextInt();
            if(stn==-1) break;
            int qn = a.nextInt();
            int gr = a.nextInt();
            b[gr/10][qn-1] ++;
            sum[gr/10]++;

        }
        for (int i = 0; i< 10 ; i++) {
            for (int j = 0; j < 3; j++)
                System.out.print(b[i][j] + " ");
            System.out.print(sum[i]);
            System.out.println("");
        }

    }
}
