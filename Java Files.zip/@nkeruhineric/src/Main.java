import java.util.*;
public class Main {
    public static double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt((x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2));
    }


// Treasure hunt


    public static int rand(int x, int y) {
        return x + (int) (Math.random() * (y - x + 1));
    }
    public static void main(String[] args) {
        System.out.println("You are in the center of a square island");
        int x = rand(-100, 100);
        int y = rand(-100, 100);
        int px = 0;
        int py = 0;
        while (true) {
            System.out.println("Find the treasure");
            System.out.println("Use 1=North, 2=South, 3=East 4= West");
            Scanner U = new Scanner(System.in);
            System.out.println("Direction?");
            int dir = U.nextInt();
            System.out.println("Distance");
            int dist = U.nextInt();
            if (dist > 10) {
                System.out.println("Please enter a number less than 10");
            } else {
                if (px > 100 || px < -100 || py > 100 || px < -100) {
                    break;
                }
                if (dir == 1) {
                    py += dist;

                }

                if (dir == 2) {
                    py -= dist;

                }
                if (dir == 3) {
                    px += dist;

                }
                if (dir == 4) {
                    px -= dist;
                }
                if (distance(px, py, x, y) <= 3) {
                    System.out.println("Success");
                    break;
                } else {
                    System.out.println("You are" + " " + distance(0, 0, px, py) + "" + "meters away from the center of the island");
                }
            }
        }
    }
}