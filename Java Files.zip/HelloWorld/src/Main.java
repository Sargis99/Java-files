import java.util.*;
class Main {
    static public int rint(int x,int y){
        return x + (int)(Math.random()*(y-x+1));
    }
    public static double distance(double x1,double y1,double x2,double y2){
        return Math.sqrt(Math.pow(x1-x2,2) + Math.pow(y1-y2,2));
    }
    public static void main(String[] args) {
        Scanner U = new Scanner(System.in);
        int x = rint(-100, 100);
        int y = rint(-100, 100);
        int pX = 0;
        int pY = 0;
        while (true) {
            System.out.println(" Input 1 to advance to the north ");
            System.out.println(" Input 2 to advance to the south ");
            System.out.println(" Input 3 to advance to the east  ");
            System.out.println(" Input 4 to advance to the west  ");
            int inputDir = U.nextInt();
            System.out.println("Distance ?");
            int inputD = U.nextInt();
            if (inputD > 10) {
                System.out.println("Distance should be not bigger than 10 please put in another number");
            } else {
                if (inputDir == 1) {
                    pY = pY + inputD;
                }
                   else if (inputDir == 2) {
                    pY = pY - inputD;
                }
                  else if (inputDir == 3) {
                    pX = pX + inputD;
                }
               else  if (inputDir == 4) {
                    pX = pX - inputD;
                }
                if (pX > 100 || pX < -100 || pY > 100 || pY < -100) {
                    System.out.println("Game over you fell into the sea");
                    break;
                }
                else if (distance(pX,pY,x,y)<=3){
                    System.out.println("You reach the point");
                    break;
                }else
                        System.out.println("You are " + distance(pX,pY,0,0)+"  meters from the center of the island");
            }

        }
    }
}