import java.util.*;
public class Main {

       /* public static void invert(int[]x){
            int y = x.length-1;
            while(y>0){
                for(int i=0;i< y; i++){
                    int a = x[i+1];
                    x[i+1] = x[i];
                    x[i] = a;
                }
                y--;
            }
        }
*/

    public static void invert(int[]x){
        int index=x.length-1;
        for(int i=0;i<index/2;i++){
            int y = x[i];
            x[i]=x[index-i];
            x[index-i]=y;
        }
    }


    public static void main(String[] args) {
        int a[] = {1,3,4,5,6,7,8};

        invert(a);
        for(int i = 0; i < a.length ; i++)
            System.out.println(a[i]);
    }

}



