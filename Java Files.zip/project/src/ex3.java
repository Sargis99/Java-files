import java.util.*;
public class ex3 {
    public static void main(String[] args){
        Scanner U = new Scanner(System.in);
        int x;
        int y;
        while(true) {
             x = rint(-100, 100);
             y = rint(-100, 100);
            if(distance(x,y,0,0)<=100)
                break;
        }
        int x1 = 0;
        int y1 = 0;
        System.out.println("You are in the center of a square island ");
        while(true) {
            System.out.println("Use 1=North, 2=South, 3=East 4= West");
            int n = U.nextInt();
            if (n == 1 || n == 2 || n == 3 || n == 4) {
                System.out.print("Distance ? ");
                int dis = U.nextInt();
                if (dis <= 10) {
                    if (n == 1) {
                        y1 += dis;
                        if (distance(x,y,x1,y1)<= 3) {
                            System.out.println("You've riched the gold Congratulations");
                            break;
                        } else if (distance(x1, y1, 0, 0) > 100) {
                            System.out.println("You are out of island");
                            break;
                        } else
                            System.out.println("You are " + distance(x1, y1, 0, 0) + " meters away from the center of the island");
                    } else if (n == 2) {
                        y1 -= dis;
                        if (distance(x,y,x1,y1)<= 3) {
                            System.out.println("You''ve riched the gold");
                            break;
                        } else if (distance(x1, y1, 0, 0) > 100) {
                            System.out.println("You are out of island");
                            break;
                        } else
                            System.out.println("You are " + distance(x1, y1, 0, 0) + " meters away from the center of the island");
                    } else if (n == 3) {
                        x1 += dis;
                        if (distance(x,y,x1,y1)<= 3) {
                            System.out.println("You''ve riched the gold");
                            break;
                        } else if (distance(x1, y1, 0, 0) > 100) {
                            System.out.println("You fall into see");
                            break;
                        } else
                            System.out.println("You are " + distance(x1, y1, 0, 0) + " meters away from the center of the island");
                    } else if (n == 4) {
                        x1 -= dis;
                        if (distance(x,y,x1,y1)<= 3) {
                            System.out.println("You''ve riched the gold");
                            break;
                        } else if (distance(x1, y1, 0, 0) > 100) {
                            System.out.println("You are out of island");
                            break;
                        } else
                            System.out.println("You are " + distance(x1, y1, 0, 0) + " meters away from the center of the island");
                    }
                } else
                    System.out.println("Too long, the distance should be less or equal 10");
            }
            else
                System.out.println("Wrong direction");
        }
    }
    public static double distance(double x1, double y1, double x2, double y2) {
        return Math.sqrt(Math.pow((x1 - x2), 2) + Math.pow((y1 - y2), 2));
    }
    public static int rint(int x,int y){
        return x + (int)(Math.random()*(y-x+1));
    }
}
